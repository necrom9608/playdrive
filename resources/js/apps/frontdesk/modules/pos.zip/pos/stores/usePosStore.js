import { defineStore } from 'pinia'
import axios from 'axios'

function createEmptyOrder(context = 'walk_in', reservationId = null) {
    return {
        id: null,
        context,
        reservation_id: reservationId,
        items: [],
    }
}

function cloneOrder(order) {
    return {
        id: order?.id ?? null,
        context: order?.context ?? 'walk_in',
        reservation_id: order?.reservation_id ?? null,
        items: Array.isArray(order?.items)
            ? order.items.map(item => ({
                line_id: item.line_id ?? crypto.randomUUID(),
                product_id: item.product_id ?? item.id,
                name: item.name,
                price_incl_vat: Number(item.price_incl_vat ?? 0),
                quantity: Number(item.quantity ?? 0),
            }))
            : [],
    }
}

export const usePosStore = defineStore('pos', {
    state: () => ({
        categories: [],
        products: [],
        selectedCategoryId: null,
        loadingCatalog: false,

        reservations: [],
        loadingReservations: false,

        selectedReservationId: null,
        reservationSearch: '',
        reservationViewMode: 'today',
        reservationStatusFilters: {
            new: true,
            confirmed: true,
            checked_in: true,
            checked_out: true,
            paid: false,
            cancelled: false,
            no_show: false,
        },

        walkInOrder: createEmptyOrder('walk_in', null),
        reservationOrders: {},
        lastAddedLineId: null,
    }),

    getters: {
        filteredProducts(state) {
            if (!state.selectedCategoryId) {
                return state.products
            }

            return state.products.filter(
                product => product.product_category_id === state.selectedCategoryId
            )
        },

        selectedReservation(state) {
            return state.reservations.find(r => r.id === state.selectedReservationId) ?? null
        },

        currentOrder(state) {
            if (state.selectedReservationId) {
                return state.reservationOrders[state.selectedReservationId]
                    ?? createEmptyOrder('reservation', state.selectedReservationId)
            }

            return state.walkInOrder
        },

        currentOrderItems() {
            return this.currentOrder.items
        },

        orderSubtotal() {
            return this.currentOrder.items.reduce((sum, item) => {
                return sum + (Number(item.price_incl_vat) * Number(item.quantity))
            }, 0)
        },

        orderCount() {
            return this.currentOrder.items.reduce((sum, item) => {
                return sum + Number(item.quantity)
            }, 0)
        },

        currentOrderLabel() {
            if (this.selectedReservation) {
                return `Actieve reservatie: ${this.selectedReservation.name}`
            }

            return 'Losse verkoop'
        },

        filteredReservations(state) {
            let items = [...state.reservations]

            const activeStatuses = Object.entries(state.reservationStatusFilters)
                .filter(([, enabled]) => enabled)
                .map(([status]) => status)

            items = items.filter(reservation => activeStatuses.includes(reservation.status))

            const q = state.reservationSearch.trim().toLowerCase()

            if (!q) {
                return items
            }

            return items.filter((reservation) => {
                return [
                    reservation.name,
                    reservation.phone,
                    reservation.email,
                    reservation.municipality,
                ]
                    .filter(Boolean)
                    .some(value => String(value).toLowerCase().includes(q))
            })
        },

        reservationStats(state) {
            const totalReservations = state.reservations.length
            const totalPersons = state.reservations.reduce((sum, r) => sum + Number(r.total_count ?? 0), 0)

            const confirmed = state.reservations.filter(r => r.status === 'confirmed')
            const checkedIn = state.reservations.filter(r => r.status === 'checked_in')
            const checkedOut = state.reservations.filter(r => r.status === 'checked_out')
            const noShow = state.reservations.filter(r => r.status === 'no_show')

            const sumPersons = (items) => items.reduce((sum, r) => sum + Number(r.total_count ?? 0), 0)

            return {
                totalReservations,
                totalPersons,
                confirmedReservations: confirmed.length,
                confirmedPersons: sumPersons(confirmed),
                checkedInReservations: checkedIn.length,
                checkedInPersons: sumPersons(checkedIn),
                checkedOutReservations: checkedOut.length,
                checkedOutPersons: sumPersons(checkedOut),
                noShowReservations: noShow.length,
                noShowPersons: sumPersons(noShow),
            }
        },
    },

    actions: {
        async loadCatalog() {
            this.loadingCatalog = true

            try {
                const [categoriesResponse, productsResponse] = await Promise.all([
                    axios.get('/api/backoffice/product-categories'),
                    axios.get('/api/backoffice/products'),
                ])

                this.categories = categoriesResponse.data
                this.products = productsResponse.data
            } finally {
                this.loadingCatalog = false
            }
        },

        async fetchReservations() {
            this.loadingReservations = true

            try {
                const response = await axios.get('/api/frontdesk/registrations')
                this.reservations = response.data.data ?? []
            } catch (error) {
                console.error('Failed to fetch reservations', error)
            } finally {
                this.loadingReservations = false
            }
        },

        addReservation(reservation) {
            this.reservations.unshift(reservation)
        },

        updateReservation(updatedReservation) {
            const index = this.reservations.findIndex(item => item.id === updatedReservation.id)

            if (index === -1) {
                this.reservations.unshift(updatedReservation)
                return
            }

            this.reservations[index] = updatedReservation
        },

        removeReservation(id) {
            this.reservations = this.reservations.filter(item => item.id !== id)

            if (this.selectedReservationId === id) {
                this.selectedReservationId = null
            }

            if (this.reservationOrders[id]) {
                delete this.reservationOrders[id]
            }
        },

        selectCategory(categoryId) {
            this.selectedCategoryId = categoryId
        },

        ensureReservationOrder(reservationId) {
            if (!this.reservationOrders[reservationId]) {
                this.reservationOrders[reservationId] = createEmptyOrder('reservation', reservationId)
            }

            return this.reservationOrders[reservationId]
        },

        getMutableCurrentOrder() {
            if (this.selectedReservationId) {
                return this.ensureReservationOrder(this.selectedReservationId)
            }

            if (!this.walkInOrder) {
                this.walkInOrder = createEmptyOrder('walk_in', null)
            }

            return this.walkInOrder
        },

        addProduct(product) {
            const order = this.getMutableCurrentOrder()
            const items = order.items
            const lastItem = items.length ? items[items.length - 1] : null

            if (lastItem && Number(lastItem.product_id) === Number(product.id)) {
                lastItem.quantity += 1
                this.lastAddedLineId = lastItem.line_id
                return
            }

            const newLine = {
                line_id: crypto.randomUUID(),
                product_id: product.id,
                name: product.name,
                price_incl_vat: Number(product.price_incl_vat ?? product.price ?? 0),
                quantity: 1,
            }

            items.push(newLine)
            this.lastAddedLineId = newLine.line_id
        },

        increaseItem(lineId) {
            const order = this.getMutableCurrentOrder()
            const item = order.items.find(entry => entry.line_id === lineId)

            if (item) {
                item.quantity += 1
                this.lastAddedLineId = item.line_id
            }
        },

        decreaseItem(lineId) {
            const order = this.getMutableCurrentOrder()
            const item = order.items.find(entry => entry.line_id === lineId)

            if (!item) {
                return
            }

            item.quantity -= 1
            this.lastAddedLineId = item.line_id

            if (item.quantity <= 0) {
                this.removeItem(lineId)
            }
        },

        removeItem(lineId) {
            const order = this.getMutableCurrentOrder()
            order.items = order.items.filter(item => item.line_id !== lineId)

            if (this.lastAddedLineId === lineId) {
                this.lastAddedLineId = order.items.length
                    ? order.items[order.items.length - 1].line_id
                    : null
            }
        },

        clearOrder() {
            this.lastAddedLineId = null

            if (this.selectedReservationId) {
                this.reservationOrders[this.selectedReservationId] = createEmptyOrder(
                    'reservation',
                    this.selectedReservationId
                )
                return
            }

            this.walkInOrder = createEmptyOrder('walk_in', null)
        },

        replaceWalkInOrder(order) {
            this.walkInOrder = cloneOrder({
                ...order,
                context: 'walk_in',
                reservation_id: null,
            })
        },

        replaceReservationOrder(reservationId, order) {
            this.reservationOrders[reservationId] = cloneOrder({
                ...order,
                context: 'reservation',
                reservation_id: reservationId,
            })
        },

        selectReservation(id) {
            this.selectedReservationId = id

            if (id) {
                this.ensureReservationOrder(id)
            }

            this.lastAddedLineId = null
        },

        clearReservationSelection() {
            this.selectedReservationId = null
            this.lastAddedLineId = null
        },

        setReservationSearch(value) {
            this.reservationSearch = value
        },

        setReservationViewMode(mode) {
            this.reservationViewMode = mode

            if (mode === 'open') {
                this.applyOpenReservationFilters()
            }

            if (mode === 'today') {
                this.resetReservationStatusFilters()
            }

            if (mode === 'date') {
                this.resetReservationStatusFilters()
            }
        },

        toggleReservationStatusFilter(status) {
            this.reservationStatusFilters[status] = !this.reservationStatusFilters[status]
        },

        resetReservationStatusFilters() {
            this.reservationStatusFilters = {
                new: true,
                confirmed: true,
                checked_in: true,
                checked_out: true,
                paid: false,
                cancelled: false,
                no_show: false,
            }
        },

        applyOpenReservationFilters() {
            this.reservationStatusFilters = {
                new: true,
                confirmed: true,
                checked_in: false,
                checked_out: false,
                paid: false,
                cancelled: false,
                no_show: false,
            }
        },
    },
})
