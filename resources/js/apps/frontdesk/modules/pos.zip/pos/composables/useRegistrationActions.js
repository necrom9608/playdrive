import axios from 'axios'
import { computed, ref } from 'vue'

export function useRegistrationActions(store) {
    const showRegistrationModal = ref(false)
    const showFilters = ref(false)
    const editingReservationId = ref(null)

    const editingReservation = computed(() => {
        if (!editingReservationId.value) {
            return {}
        }

        return store.reservations.find(
            item => item.id === editingReservationId.value
        ) ?? {}
    })

    function openNewRegistrationModal() {
        editingReservationId.value = null
        showRegistrationModal.value = true
    }

    function openEditRegistrationModal() {
        if (!store.selectedReservationId) return

        editingReservationId.value = store.selectedReservationId
        showRegistrationModal.value = true
    }

    function closeRegistrationModal() {
        showRegistrationModal.value = false
        editingReservationId.value = null
    }

    async function handleRegistrationSubmit(payload) {
        try {
            let response

            if (payload.id) {
                response = await axios.put(`/api/frontdesk/registrations/${payload.id}`, payload)
                store.updateReservation(response.data.data)
            } else {
                response = await axios.post('/api/frontdesk/registrations', payload)
                store.addReservation(response.data.data)
            }

            closeRegistrationModal()
        } catch (error) {
            console.error(error)

            if (error.response?.status === 422) {
                console.log('validation errors', error.response.data.errors)
            }
        }
    }

    async function handleCheckIn() {
        if (!store.selectedReservationId) return

        try {
            const response = await axios.post(
                `/api/frontdesk/registrations/${store.selectedReservationId}/check-in`
            )

            store.updateReservation(response.data.data)
        } catch (error) {
            console.error(error)
        }
    }

    async function handleCheckOut() {
        if (!store.selectedReservationId) return

        try {
            const response = await axios.post(
                `/api/frontdesk/registrations/${store.selectedReservationId}/check-out`
            )

            store.updateReservation(response.data.data)
        } catch (error) {
            console.error(error)
        }
    }

    async function handleCancelReservation() {
        if (!store.selectedReservationId) return

        try {
            const response = await axios.post(
                `/api/frontdesk/registrations/${store.selectedReservationId}/cancel`
            )

            store.updateReservation(response.data.data)
        } catch (error) {
            console.error(error)
        }
    }

    async function handleNoShowReservation() {
        if (!store.selectedReservationId) return

        try {
            const response = await axios.post(
                `/api/frontdesk/registrations/${store.selectedReservationId}/no-show`
            )

            store.updateReservation(response.data.data)
        } catch (error) {
            console.error(error)
        }
    }

    async function handleDeleteReservation() {
        if (!store.selectedReservationId) return

        const id = store.selectedReservationId
        const confirmed = window.confirm('Ben je zeker dat je deze registratie wil verwijderen?')

        if (!confirmed) return

        try {
            await axios.delete(`/api/frontdesk/registrations/${id}`)
            store.removeReservation(id)
        } catch (error) {
            console.error(error)
        }
    }

    function toggleStatusFilter(value) {
        store.toggleReservationStatusFilter(value)
    }

    function resetFilters() {
        store.resetReservationStatusFilters()
    }

    function closeFilters() {
        showFilters.value = false
    }

    function toggleFilters() {
        showFilters.value = !showFilters.value
    }

    return {
        showRegistrationModal,
        showFilters,
        editingReservation,
        openNewRegistrationModal,
        openEditRegistrationModal,
        closeRegistrationModal,
        handleRegistrationSubmit,
        handleCheckIn,
        handleCheckOut,
        handleCancelReservation,
        handleNoShowReservation,
        handleDeleteReservation,
        toggleStatusFilter,
        resetFilters,
        closeFilters,
        toggleFilters,
    }
}
