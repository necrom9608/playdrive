<template>
    <div class="rounded-3xl border border-slate-800 bg-slate-900 shadow-xl">
        <div class="border-b border-slate-800 p-4">
            <h3 class="text-lg font-semibold text-white">Dagoverzicht</h3>
            <p class="mt-1 text-sm text-slate-400">
                Eén rij per reservatie, met statuskleur en metadata.
            </p>
        </div>

        <div v-if="!registrations.length" class="p-6 text-sm text-slate-400">
            Geen reservaties voor deze dag.
        </div>

        <div v-else class="divide-y divide-slate-800">
            <article
                v-for="registration in registrations"
                :key="registration.id"
                class="relative overflow-hidden"
            >
                <div
                    class="flex items-stretch"
                    :class="[
                        registration.status_color?.bg ?? 'bg-slate-500/10',
                        registration.status_color?.border ?? 'border-slate-500/20',
                    ]"
                >
                    <div
                        class="w-2 shrink-0"
                        :class="registration.status_color?.accent ?? 'bg-slate-500'"
                    ></div>

                    <div class="min-w-0 flex-1 p-4">
                        <div class="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                            <div class="min-w-0 flex-1">
                                <div class="flex flex-wrap items-center gap-2">
                                    <h4 class="text-base font-semibold text-white">
                                        {{ registration.name || `Reservatie #${registration.id}` }}
                                    </h4>

                                    <span
                                        class="inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ring-1"
                                        :class="registration.status_color?.badge ?? 'bg-slate-500/15 text-slate-300 ring-slate-500/30'"
                                    >
                                        {{ registration.status_label }}
                                    </span>

                                    <span
                                        v-if="registration.outside_opening_hours"
                                        class="inline-flex items-center rounded-full bg-amber-500/15 px-2.5 py-1 text-xs font-semibold text-amber-300 ring-1 ring-amber-500/30"
                                    >
                                        Buiten openingsuren
                                    </span>

                                    <span
                                        v-if="registration.invoice_requested"
                                        class="inline-flex items-center rounded-full bg-cyan-500/15 px-2.5 py-1 text-xs font-semibold text-cyan-300 ring-1 ring-cyan-500/30"
                                    >
                                        Factuur
                                    </span>
                                </div>

                                <div class="mt-2 flex flex-wrap items-center gap-2 text-sm text-slate-300">
                                    <span
                                        class="inline-flex items-center rounded-xl bg-slate-800/80 px-2.5 py-1 font-medium text-slate-200"
                                    >
                                        {{ registration.event_time || 'Geen uur' }}
                                    </span>

                                    <span
                                        v-if="registration.duration_label"
                                        class="inline-flex items-center rounded-xl bg-slate-800/80 px-2.5 py-1 font-medium text-slate-200"
                                    >
                                        {{ registration.duration_label }}
                                    </span>

                                    <span
                                        class="inline-flex items-center rounded-xl bg-slate-800/80 px-2.5 py-1 font-medium text-slate-200"
                                    >
                                        {{ registration.total_count }} pers.
                                    </span>
                                </div>

                                <div class="mt-3 flex flex-wrap gap-2">
                                    <MetaTag
                                        v-if="registration.event_type"
                                        :emoji="registration.event_type_emoji"
                                        :label="registration.event_type"
                                    />

                                    <MetaTag
                                        v-if="registration.catering_option"
                                        :emoji="registration.catering_option_emoji"
                                        :label="registration.catering_option"
                                    />

                                    <MetaTag
                                        v-if="registration.participants_children"
                                        label="Kinderen"
                                        :value="registration.participants_children"
                                    />

                                    <MetaTag
                                        v-if="registration.participants_adults"
                                        label="Volwassenen"
                                        :value="registration.participants_adults"
                                    />

                                    <MetaTag
                                        v-if="registration.participants_supervisors"
                                        label="Begeleiders"
                                        :value="registration.participants_supervisors"
                                    />
                                </div>

                                <p
                                    v-if="registration.comment"
                                    class="mt-3 rounded-2xl bg-slate-950/60 px-3 py-2 text-sm text-slate-300"
                                >
                                    {{ registration.comment }}
                                </p>
                            </div>

                            <div class="grid shrink-0 grid-cols-2 gap-2 xl:min-w-[220px]">
                                <div class="rounded-2xl bg-slate-950/60 px-3 py-2">
                                    <div class="text-xs uppercase tracking-wide text-slate-500">Start</div>
                                    <div class="mt-1 text-sm font-semibold text-white">
                                        {{ registration.event_time || '—' }}
                                    </div>
                                </div>

                                <div class="rounded-2xl bg-slate-950/60 px-3 py-2">
                                    <div class="text-xs uppercase tracking-wide text-slate-500">Einde</div>
                                    <div class="mt-1 text-sm font-semibold text-white">
                                        {{ endTimeLabel(registration) }}
                                    </div>
                                </div>

                                <div
                                    v-if="registration.checked_in_at"
                                    class="rounded-2xl bg-slate-950/60 px-3 py-2"
                                >
                                    <div class="text-xs uppercase tracking-wide text-slate-500">In</div>
                                    <div class="mt-1 text-sm font-semibold text-white">
                                        {{ formatDateTime(registration.checked_in_at) }}
                                    </div>
                                </div>

                                <div
                                    v-if="registration.checked_out_at"
                                    class="rounded-2xl bg-slate-950/60 px-3 py-2"
                                >
                                    <div class="text-xs uppercase tracking-wide text-slate-500">Uit</div>
                                    <div class="mt-1 text-sm font-semibold text-white">
                                        {{ formatDateTime(registration.checked_out_at) }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        </div>
    </div>
</template>

<script setup>
    import { computed } from 'vue'

    const props = defineProps({
        registrations: {
            type: Array,
            default: () => [],
        },
    })

    const MetaTag = {
        props: {
            emoji: {
                type: String,
                default: null,
            },
            label: {
                type: String,
                required: true,
            },
            value: {
                type: [String, Number],
                default: null,
            },
        },
        computed: {
            text() {
                return this.value !== null && this.value !== undefined
                    ? `${this.label}: ${this.value}`
                    : this.label
            },
        },
        template: `
        <span class="inline-flex items-center gap-1 rounded-full bg-slate-800/90 px-3 py-1.5 text-xs font-medium text-slate-200 ring-1 ring-slate-700">
            <span v-if="emoji">{{ emoji }}</span>
            <span>{{ text }}</span>
        </span>
    `,
    }

    function endTimeLabel(registration) {
        if (registration.end_at) {
            return formatTime(registration.end_at)
        }

        return '—'
    }

    function formatTime(value) {
        const date = new Date(value)

        if (Number.isNaN(date.getTime())) {
            return '—'
        }

        return new Intl.DateTimeFormat('nl-BE', {
            hour: '2-digit',
            minute: '2-digit',
        }).format(date)
    }

    function formatDateTime(value) {
        const date = new Date(value)

        if (Number.isNaN(date.getTime())) {
            return '—'
        }

        return new Intl.DateTimeFormat('nl-BE', {
            hour: '2-digit',
            minute: '2-digit',
        }).format(date)
    }
</script>
