<template>
    <div class="flex h-full min-h-0 flex-col overflow-hidden rounded-3xl border border-slate-800 bg-slate-900 shadow-xl">
        <div class="shrink-0 border-b border-slate-800 px-4 py-3">
            <h3 class="text-lg font-semibold text-white">Maandoverzicht</h3>
            <p class="mt-1 text-sm text-slate-400">
                Kalender met totalen per dag. Klik op een dag om het dagoverzicht te openen.
            </p>
        </div>

        <div class="shrink-0 grid grid-cols-7 border-b border-slate-800 bg-slate-950/60 text-center text-[11px] font-semibold uppercase tracking-wide text-slate-500">
            <div
                v-for="label in weekdayLabels"
                :key="label"
                class="px-2 py-2"
            >
                {{ label }}
            </div>
        </div>

        <div class="min-h-0 flex-1">
            <div
                class="grid h-full grid-cols-7 gap-px bg-slate-800"
                :style="{ gridTemplateRows: `repeat(${rowCount}, minmax(0, 1fr))` }"
            >
                <button
                    v-for="day in days"
                    :key="day.date"
                    type="button"
                    class="overflow-hidden bg-slate-950 px-2 py-1.5 text-left align-top transition hover:bg-slate-900"
                    :class="[
                        day.is_today ? 'ring-1 ring-inset ring-blue-500' : '',
                        !day.is_current_month ? 'bg-slate-950/60' : '',
                    ]"
                    @click="$emit('select-day', day.date)"
                >
                    <div class="flex items-start justify-between gap-2">
                        <span
                            class="text-sm font-semibold leading-none"
                            :class="day.is_selected ? 'text-blue-400' : (!day.is_current_month ? 'text-slate-500' : 'text-white')"
                        >
                            {{ day.day_number }}
                        </span>

                        <span class="rounded-full bg-slate-800 px-1.5 py-0.5 text-[10px] font-semibold leading-none text-slate-300">
                            {{ day.totals.participants }}
                        </span>
                    </div>

                    <div class="mt-1 text-[10px] leading-none text-slate-500">
                        {{ day.totals.reservations }} res.
                    </div>

                    <div class="mt-1.5 flex flex-col gap-1">
                        <span
                            v-for="status in visibleStatusTotals(day)"
                            :key="`status-${day.date}-${status.key}`"
                            class="inline-flex max-w-full items-center gap-1 self-start rounded-full px-1.5 py-0.5 text-[10px] font-medium leading-none ring-1"
                            :class="status.colors.badge"
                            :title="`${status.label}: ${status.people_count} personen`"
                        >
                            <span class="h-1.5 w-1.5 shrink-0 rounded-full" :class="status.colors.accent"></span>
                            <span class="truncate">{{ shortStatusLabel(status.label) }}</span>
                            <span class="shrink-0 font-semibold">{{ status.people_count }}</span>
                        </span>

                        <span
                            v-for="catering in visibleCateringTotals(day)"
                            :key="`catering-${day.date}-${catering.key}`"
                            class="inline-flex max-w-full items-center gap-1 self-start rounded-full px-1.5 py-0.5 text-[10px] font-medium leading-none ring-1"
                            :class="catering.badge"
                            :title="`${catering.label}: ${catering.people_count} personen`"
                        >
                            <span class="h-1.5 w-1.5 shrink-0 rounded-full" :class="catering.accent"></span>
                            <span class="truncate">
                                <span v-if="catering.emoji" class="mr-0.5">{{ catering.emoji }}</span>
                                {{ shortCateringLabel(catering.label) }}
                            </span>
                            <span class="shrink-0 font-semibold">{{ catering.people_count }}</span>
                        </span>
                    </div>
                </button>
            </div>
        </div>
    </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
    days: {
        type: Array,
        default: () => [],
    },
})

defineEmits(['select-day'])

const weekdayLabels = ['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo']

const rowCount = computed(() => {
    const count = Math.ceil((props.days?.length ?? 0) / 7)
    return Math.max(count, 1)
})

function visibleStatusTotals(day) {
    return (day?.status_totals ?? [])
        .map(status => ({
            ...status,
            people_count: Number(status.people_count ?? 0),
        }))
        .filter(status => status.people_count > 0)
        .slice(0, 2)
}

function visibleCateringTotals(day) {
    return (day?.catering_totals ?? [])
        .map(item => ({
            ...item,
            people_count: Number(item.people_count ?? 0),
        }))
        .filter(item => item.people_count > 0)
        .slice(0, 1)
}

function shortStatusLabel(label) {
    const map = {
        Nieuw: 'Nieuw',
        Bevestigd: 'Bevest.',
        Ingecheckt: 'In',
        Uitgecheckt: 'Uit',
        Betaald: 'Betaald',
        Geannuleerd: 'Geann.',
        'No-show': 'No-show',
    }

    return map[label] ?? label
}

function shortCateringLabel(label) {
    if (!label) {
        return 'Catering'
    }

    return label.length > 14 ? `${label.slice(0, 12)}…` : label
}
</script>
